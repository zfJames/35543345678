/*Utilities.h -- containing helpful using definitions for all files
 *CSIS 112-D01 LUO
 *No citations necessary
 */

#pragma once
#ifndef UTILITIES_H
#define UTILITIES_H
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <string>

#endif